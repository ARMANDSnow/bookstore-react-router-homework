# 知页书城 · 作业3源码与运行说明

524031910745 丁宇轩

本包为可独立启动的前端、Spring后端与中文Embedding伴随服务。价格、库存及服务政策为课程演示数据。退款执行与会员抵扣未实现；向导只读查询，不修改业务数据。

## 环境

- Node.js 22.12+、npm；JDK 17或更新、Maven；MySQL 8（有创建数据库权限的账户）；Python 3与curl。
- 首次npm安装、Maven依赖及模型下载需要互联网。模型固定为Xenova/bge-small-zh-v1.5，revision 75c43b069aac4d136ba6bc1122f995fedcfd2781，CPU q8、CLS池化、512维单位向量。
- DeepSeek真实调用需要账户中可用的API密钥和额度。本包不含密钥，也不含node_modules、编译产物或模型缓存。

## 三项服务启动

1. 在源码包根目录运行 `npm ci`。
2. 在 `embedding-service` 运行 `npm ci`、`npm run download-model`。下载脚本通过curl取得固定模型文件，并核验ONNX SHA256。成功后运行 `npm start`，监听127.0.0.1:8091。检查 `curl http://127.0.0.1:8091/status`，等待status为ready后再查询。运行阶段从本地.cache读取模型，不重新联网下载；首次向量索引稍慢，后续按原文及模型版本校验缓存。
3. 将 `backend/.env.example` 复制为 `backend/.env`，填写DEEPSEEK_API_KEY及MYSQL配置；权限建议600。实际配置为https://api.deepseek.com与deepseek-flash（2026-10-06真实验证）。从backend目录运行 `mvn spring-boot:run`，监听8080；启动时创建表并导入16本课程书目，重复启动不覆盖已有业务价格库存。
4. 从源码包根目录运行 `npm run dev -- --host 127.0.0.1`，访问http://127.0.0.1:5173。开发代理默认把/api请求送到8080。

保持三个终端分别运行Embedding、后端和前端。前端可直接访问图书目录、/policies政策检索、/guide购书向导；原有登录与购物流程仍为课程功能。政策服务未ready或断开时显示不可用；向导说明无法确认条款，不编造退货许可。

使用独立端口时，例如：Embedding设 `EMBEDDING_PORT=8094`；后端设 `SERVER_PORT=8082 POLICY_BASE_URL=http://127.0.0.1:8094 MYSQL_DATABASE=bookstore_assignment3_qa`；前端设 `VITE_API_TARGET=http://127.0.0.1:8082` 并加 `--port 5182`。MYSQL账户配置照常填写。独立验收使用新数据库，不接管原工程进程。

## 验收与案例

- 后端：backend目录 `mvn test`。76项测试包含原功能、参数校验、工具白名单、tool_call_id对应、政策服务不可用、批量动作修正、实际重试额度及虚构政策编号修正。单元测试使用mock/H2，不代表真实模型。
- 前端：根目录 `npm run build`。
- 真实向量/政策：根目录 `node scripts/assignments/verify_policy.mjs`。可用BOOKSTORE_API_BASE与EMBEDDING_BASE指定实例；证据写入docs/assignments/evidence/3a-real-rag.json。
- 真实导购：根目录 `node scripts/assignments/verify_shopping.mjs`。可用BOOKSTORE_API_BASE指定实例，验证六类咨询、复合顺序、政策引用、未知项与书目只读。
- 桌面流程脚本需Ego浏览器运行环境。通过 `ego-browser nodejs` 调用 `await import('/源码绝对路径/scripts/assignments/verify_shopping_browser.mjs')`，不可直接普通node执行。在Ego脚本内设置 `process.env.EGO_TASK_SPACE` 与 `process.env.BOOKSTORE_WEB_BASE` 后再import（CLI外层环境变量不会自动传入Ego执行环境）；政策脚本同理。未安装Ego时可手动验收下面路径。
- 手动：购书向导问“推荐一本学习微服务的书，拆了塑封不喜欢还能退吗？”，核对推荐、policy-2非质量退货限制和policy-3质量例外；展开政策依据和行动记录；点推荐书卡进入详情。尝试断网后重试与开启新对话。政策页检查拆封、缺页、会员积分、无相关依据与完整条款。

`docs/assignments/作业3-复杂案例.md`给出真实复杂问题完整公开Thought→Action→Observation链与最终答复。Thought是一句公开行动目的，不是隐藏思考过程。完整结构化结果与真实请求ID在3b-real-model.json。3a/3b/3c证据及原始桌面截图只证明本地验收，不表示已部署上线；按要求未检测手机比例。

## 源码范围与可复核性

源码含前端、后端、Embedding服务、依赖锁文件、固定版本模型下载脚本、政策全文、必要配置与验收脚本。第三方模型权重由下载脚本获取，不放入源码包。MANIFEST.json列出每个文件的大小和SHA256；sourceRevision为打包时Git基线，实际文件以逐项摘要为准。ZIP时间固定，CRC与逐文件摘要均检查。包外3c-package.json记录最终ZIP摘要，避免将自身摘要收进归档。

可执行 `python3 scripts/assignments/build_submission.py 3` 重建源码包；README源文件也随包保留。不要将本机.env或密钥复制进提交材料。
