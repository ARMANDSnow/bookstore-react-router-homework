# 作业2：真实模型工具调用

学号：524031910745　姓名：丁宇轩

本包只包含自己编写的前后端源码、必要配置/依赖声明、书封素材、测试脚本与运行证据，不包含完整Git工程、node_modules、构建产物或第三方Jar。通过依赖声明重新安装依赖即可运行。

## 启动

需要Node.js 22或更新版本、JDK17或更新版本、Maven3.9、MySQL8。后端兼容本机JDK26，使用Mockito与ByteBuddy依赖覆盖。

1. 解压，在根目录执行 `npm ci`。
2. 复制 `backend/.env.example` 为 `backend/.env`，填写自己的 `DEEPSEEK_API_KEY` 和MySQL配置。数据库为本机课程环境；应用会自动建表与初始化16本书。密钥只由后端读取。
3. 在 `backend` 目录执行 `mvn spring-boot:run`，默认8080端口。
4. 在根目录执行 `npm run dev`，打开 `http://127.0.0.1:5173/assistant`。演示账号 `demo / 123456`、管理员 `admin / 123456`，助手本身不要求登录。
5. 推荐选《微服务设计（第2版）》并点击“库存和价格一起看”。

如果8080或5173占用，可运行 `SERVER_PORT=8082 mvn spring-boot:run`；前端运行 `VITE_API_TARGET=http://127.0.0.1:8082 npm run dev -- --port 5182`。

DeepSeek按官网当前接口配置：`https://api.deepseek.com/chat/completions`，模型 `deepseek-flash`，关闭thinking。配置位于 `backend/src/main/resources/application.yml`，密钥不用写进代码。工具调用协议参考 https://api-docs.deepseek.com/zh-cn/guides/tool_calls/ 。

## 实现与验收

`BookTools.java`提供 `check_inventory(isbn)`（实际MySQL库存）和 `get_competitor_price(isbn)`（明确课程模拟报价）。`AssistantService.java`按模型返回的 `tool_calls`解析白名单参数，执行函数，将完整assistant工具消息及匹配的 `tool_call_id` 结果回传真实模型，再返回自然语言答复、图书及公开查询记录。

ISBN去空格及连字符后要求13位，并精确查询数据库；不存在、不完整或存在歧义时要求用户核对，不猜测另一个ISBN。当前明确ISBN优先于历史。仅允许user/assistant历史；所有工具均只读。每个请求最多4轮模型请求、6个工具，同工具同ISBN最多执行2次。

左侧“课程异常演示”可选竞价首次模拟超时。首次工具返回 `COMPETITOR_TIMEOUT`，模型用相同ISBN重试后成功；页面保留失败与成功观察，并提示已恢复。真实模型连接失败有明确错误、编辑与重试，重试不会重复用户问题。新对话恢复普通场景。

- 后端：`cd backend && mvn test`，62项通过（包括H2与模拟模型的单元/控制器测试）。
- 前端：`npm run build`；真实桌面浏览器覆盖普通问题、追问、ISBN错误、断网重试、异常恢复、输入行为与视觉布局，未进行手机比例测试。
- 真实模型/MySQL：根目录执行 `node scripts/assignments/verify_assistant.mjs` 与 `node scripts/assignments/verify_assistant_errors.mjs`。端口变更时设置 `BOOKSTORE_API_BASE`。
- 书目：`node scripts/assignments/verify_catalog_seed.mjs`；可选 `python3 scripts/assignments/verify_seed_mysql.py` 在本机root空密码MySQL的专用临时库检查种子。
- 浏览器脚本需要Ego浏览器，通过 `EGO_TASK_SPACE` 指定自己创建的同一任务空间编号，默认11；其原始运行记录和截图已放入 `docs/assignments/evidence/`。

真实模型证据保留服务商响应ID，模拟竞价/模拟工具超时与实际网络失败明确区分。价格与库存为课程演示数据。该应用未部署，运行证据来自本机；课程演示登录仍沿用前端身份机制。

## 包验证

`MANIFEST.json`列出每个文件的SHA256与打包前Git版本。提交包不包含任何 `.env`，只有空密钥配置示例。不要把自己的配置或下载的依赖重新压缩进包。
